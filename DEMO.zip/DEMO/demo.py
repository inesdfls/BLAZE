import sys
sys.path.append('fonctions.py')
from fonctions import *


import numpy as np
import matplotlib.pyplot as plt
import cv2
from sklearn.neighbors import KDTree
from tensorflow.keras.models import load_model, Model
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.layers import Dense, Input

# Charger le modèle final
model = load_model("model_keras.h5")

# Créer un extracteur de features qui sort 562 dimensions (comme à l'entraînement)
base_model = MobileNetV2(
    weights="imagenet",
    include_top=False,
    input_shape=(224, 224, 3),
    pooling='avg'
)

# Ajouter une couche Dense(562) pour correspondre aux attentes du modèle
x = Dense(562, activation='relu')(base_model.output)
feature_model = Model(inputs=base_model.input, outputs=x)

# Charger et prétraiter l'image
image_path = "DATA/08.png"
image = load_img(image_path, target_size=(224, 224))  # Chargée en RGB
image_array = img_to_array(image)
image_array = np.expand_dims(image_array, axis=0)
image_array = preprocess_input(image_array)

# Extraire les 562 features
features = feature_model.predict(image_array)

# Faire la prédiction finale
prediction = model.predict(features)
score = prediction[0][0]
classe = "TUMEUR" if score > 0.5 else "SAIN"

if classe == "TUMEUR" :
    print(f"Résultat : {classe} (score : {score:.4f})")
    t_min = input("Entrez la température minimum de l'image (--.--): ")
    t_min = float(t_min)
    t_max = input("Entrez la température maximum de l'image (--.--): ")
    t_max = float(t_max)
    if t_min>t_max :
        print("température minimum supérieur à la température maximum")
    else :
        matrice = process_thermal_image_with_external_palette("DATA/08.png", "DATA/palette.png", temp_min=t_min, temp_max=t_max)
        res = process_temperature_matrix(matrice)
        signature = generate_thermal_signature(res)

        plt.title("Température (°C)")
        plt.imshow(matrice, cmap='inferno')
        plt.colorbar(label="Température")
        plt.axis('off')
        plt.show()


        a_range = np.linspace(-0.05, 0.05, 501)  # ±5 cm autour du centre, en mètres
        a_cm = 1  # espacement entre chaque profil en cm

        plt.figure(figsize=(10, 6))

        for i, profile in enumerate(signature):
            if isinstance(profile, np.ndarray) and not np.all(np.isnan(profile)):
                plt.plot(a_range * 100, profile, label=f'd = {(i + 1) * a_cm} cm')

        plt.xlabel("Distance from Tmax center (cm)")
        plt.ylabel("Temperature (K)")
        plt.title("Thermal Signatures")
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.show()
else :
    print(f"Résultat : {classe} (score : {score:.4f})")
        
