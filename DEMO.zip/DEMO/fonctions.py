import cv2
import numpy as np
from sklearn.neighbors import KDTree
import matplotlib.pyplot as plt

def process_thermal_image_with_external_palette(image_path, palette_path,
                                                temp_min=20.4, temp_max=29.0,
                                                cross_half_length=5, cross_thickness=1,
                                                crop_top=27, crop_bottom=223):
    """
    Traite une image thermique en utilisant une palette fournie par image externe.

    Args:
        image_path (str): Chemin vers l'image thermique à analyser.
        palette_path (str): Chemin vers l'image de la palette de référence.
        temp_min (float): Température minimale (correspondant à la gauche de la palette).
        temp_max (float): Température maximale (droite de la palette).
        cross_half_length (int): Demi-longueur de la croix centrale.
        cross_thickness (int): Épaisseur de la croix.
        crop_top (int): Ligne de début du recadrage.
        crop_bottom (int): Ligne de fin du recadrage (exclue).

    Returns:
        np.ndarray: Matrice de température recadrée.
    """
    # Charger les images
    img = cv2.imread(image_path)
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    palette_img = cv2.imread(palette_path)
    palette_rgb = cv2.cvtColor(palette_img, cv2.COLOR_BGR2RGB)

    h, w = img_rgb.shape[:2]
    cx, cy = w // 2, h // 2

    # Supprimer la croix centrale
    def remove_cross(img, cx, cy, L=5, T=1):
        for dx in range(-L, L + 1):
            for dy in range(-T, T + 1):
                x, y = cx + dx, cy + dy
                if 0 <= x < img.shape[1] and 0 <= y < img.shape[0]:
                    neighbors = []
                    for nx in range(-2, 3):
                        for ny in range(-2, 3):
                            if nx == 0 and ny == 0:
                                continue
                            xx, yy = x + nx, y + ny
                            if 0 <= xx < img.shape[1] and 0 <= yy < img.shape[0]:
                                neighbors.append(img[yy, xx])
                    if neighbors:
                        img[y, x] = np.mean(neighbors, axis=0)

        for dy in range(-L, L + 1):
            for dx in range(-T, T + 1):
                x, y = cx + dx, cy + dy
                if 0 <= x < img.shape[1] and 0 <= y < img.shape[0]:
                    neighbors = []
                    for nx in range(-2, 3):
                        for ny in range(-2, 3):
                            if nx == 0 and ny == 0:
                                continue
                            xx, yy = x + nx, y + ny
                            if 0 <= xx < img.shape[1] and 0 <= yy < img.shape[0]:
                                neighbors.append(img[yy, xx])
                    if neighbors:
                        img[y, x] = np.mean(neighbors, axis=0)

    img_cleaned = img_rgb.copy()
    remove_cross(img_cleaned, cx, cy, L=cross_half_length, T=cross_thickness)

    # Extraire les couleurs de la palette horizontale (on prend la ligne du milieu)
    palette_line = palette_rgb[palette_rgb.shape[0] // 2, :, :]
    palette_colors = palette_line.reshape(-1, 3)
    tree = KDTree(palette_colors)

    # Associer chaque pixel à une température
    temp_matrix = np.zeros((h, w), dtype=np.float32)
    for y in range(h):
        for x in range(w):
            pixel = img_cleaned[y, x].reshape(1, -1)
            _, idx = tree.query(pixel, return_distance=True)
            rel_pos = idx[0][0] / (len(palette_colors) - 1)
            temp = temp_min + rel_pos * (temp_max - temp_min)
            temp_matrix[y, x] = temp

    # Recadrage
    temp_matrix_cropped = temp_matrix[crop_top:crop_bottom, :]

    return temp_matrix_cropped

def process_temperature_matrix(thermal_matrix, pixels_per_cm=2, distance_cm=1):

    # Find the maximum temperature (Tmax) and its location
    Tmax = np.max(thermal_matrix)
    max_row, max_col = np.unravel_index(np.argmax(thermal_matrix), thermal_matrix.shape)

    # Convert distance from cm to pixels
    distance_pixels = int(distance_cm * pixels_per_cm)

    # Sample temperatures along the vertical axis at intervals of 'distance_pixels' below Tmax
    temperatures_at_distance = []
    for i in range(10):
        y = max_row - (i + 1) * distance_pixels
        x = max_col
        if 0 <= y < thermal_matrix.shape[0]:
            temperatures_at_distance.append(thermal_matrix[y, x])

    # Mean temperature outside the ROI
    Te = np.float32(25) #np.mean(thermal_matrix)

    return Tmax, temperatures_at_distance, Te, distance_cm


# Constants from the Brazilian source code
h0 = 8.77            # W·m⁻²·K⁻¹ — Convective heat transfer coefficient
Ta_blood = 310.15    # K         — Arterial blood temperature ≈ 37°C
qm = 700             # W·m⁻³     — Metabolic heat generation in healthy tissue

# Mathematical Modeling
# Based on equations (17), (18), (20), and (16) from RASTGAR-JAZI & MOHAMMADI (2017)

def eq17_depth_d(Ta, Tmax, Te, a):
    """
    Compute the heat source depth `d` in meters.

    Equation (17): d = a * sqrt((Ta - Te) / (Tmax - Ta))

    Parameters:
        Ta (float): Arterial temperature [K]
        Tmax (float): Maximum surface temperature [K]
        Te (float): Background (non-ROI) temperature [K]
        a (float): Reference distance from the hot spot center [m]

    Returns:
        float: Estimated depth [m]
    """
    return a * np.sqrt((Ta - Te) / (Tmax - Ta))

def eq18_intensity_Q(Ta, Tmax, Te, a, h0=h0):
    """
    Compute thermal power `Q` in watts.

    Equation (18): Q = (4πh₀ (Ta - Te)(Tmax - Te) a²) / (Tmax - Ta)

    Parameters:
        Ta (float): Arterial temperature [K]
        Tmax (float): Maximum surface temperature [K]
        Te (float): Background (non-ROI) temperature [K]
        a (float): Reference distance from the hot spot center [m]
        h0 (float): Convective heat transfer coefficient [W·m⁻²·K⁻¹]

    Returns:
        float: Estimated power output [W]
    """
    return (4 * np.pi * h0 * (Ta - Te) * (Tmax - Te) * a**2) / (Tmax - Ta)

def eq20_radius_R(d, a, Ta_blood=Ta_blood, Te=25, h0=h0, qm=qm):
    """
    Compute the tumor radius `R` in meters.

    Equation (20): R³ = ((Ta_blood - Te)(a² + d²)) / (4πh₀qₘ × 10⁶)

    Parameters:
        d (float): Depth of the heat source [m]
        a (float): Reference distance from the hot spot center [m]
        Ta_blood (float): Arterial blood temperature [K]
        Te (float): Background temperature [K]
        h0 (float): Convective heat transfer coefficient [W·m⁻²·K⁻¹]
        qm (float): Metabolic heat production [W·m⁻³]

    Returns:
        float: Estimated tumor radius [m]
    """
    R_cubed = ((Ta_blood - Te) * (a**2 + d**2)) / (4 * np.pi * h0 * qm * 1e6)
    return np.cbrt(R_cubed)

def eq16_T_profile(a_array, Te, d, R, Q, h0=h0):
    """
    Compute the theoretical temperature profile T(a) at different distances.

    Equation (16): T(a) = Te + Q / (4h₀[(d + R)² + a²])

    Parameters:
        a_array (np.ndarray): Array of distances from the hot spot center [m]
        Te (float): Background temperature [K]
        d (float): Depth of the heat source [m]
        R (float): Radius of the heat source [m]
        Q (float): Heat output [W]
        h0 (float): Convective heat transfer coefficient [W·m⁻²·K⁻¹]

    Returns:
        np.ndarray: Temperature profile [K]
    """
    return Te + Q / (4 * h0 * ((d + R)**2 + a_array**2))

# Temperature Conversion
def C_to_K(Tc):
    """Convert temperature from Celsius to Kelvin."""
    #return np.array(Tc, dtype=np.float32) + 273.15
    return float(Tc) + 273.15


def generate_thermal_signature(resultat_temperature_matrice):
    Te_C = resultat_temperature_matrice[2]            # float
    Ta_C_list = resultat_temperature_matrice[1]       # list
    Tmax_C = resultat_temperature_matrice[0]          # float
    a_cm = resultat_temperature_matrice[3]            # float

    signature_profiles = []

    # Convert to Kelvin
    Te = C_to_K(Te_C)
    Tmax = C_to_K(Tmax_C)

    for j, Ta_C in enumerate(Ta_C_list):
        Ta = C_to_K(Ta_C)
        a = a_cm / 100.0 * (j + 1)  # cm to m

        # Compute physical parameters
        d_est = eq17_depth_d(Ta, Tmax, Te, a)
        print(d_est)
        Q_est = eq18_intensity_Q(Ta, Tmax, Te, a)
        print(Q_est)
        R_est = eq20_radius_R(d_est, a)
        print(R_est)

        # Profile over ±5 cm
        a_range = np.linspace(-0.05, 0.05, 501)
        T_profile = eq16_T_profile(a_range, Te, d_est, R_est, Q_est)

        signature_profiles.append(T_profile)

    return signature_profiles
